import { useLocation } from 'wouter';

export default function Home() {
  const [, setLocation] = useLocation();

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">ZiiOZ PulsePerk Manager</h1>
      <button
        className="mt-4 px-4 py-2 bg-purple-600 text-white rounded"
        onClick={() => setLocation('/checkout')}
      >
        Purchase Campaign
      </button>
    </div>
  );
}
