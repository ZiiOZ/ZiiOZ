import { useLocation } from 'wouter';

export default function Home() {
  const [, setLocation] = useLocation();
  const handlePurchase = () => setLocation('/checkout');
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">ZiiOZ PulsePerk Ad Manager</h1>
      <button onClick={handlePurchase} className="mt-4 px-4 py-2 bg-blue-600 text-white rounded">
        Purchase Campaign
      </button>
    </div>
  );
}
