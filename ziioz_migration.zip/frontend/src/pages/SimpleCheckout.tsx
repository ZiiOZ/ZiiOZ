import { useEffect, useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';

export default function SimpleCheckout() {
  const [clientSecret, setClientSecret] = useState('');

  useEffect(() => {
    fetch(`${import.meta.env.VITE_BACKEND_URL}/create-payment-intent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount: 1000 })
    })
      .then(res => res.json())
      .then(data => setClientSecret(data.clientSecret));
  }, []);

  useEffect(() => {
    if (!clientSecret) return;
    (async () => {
      const stripe = await loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);
      if (!stripe) return;
      const result = await stripe.confirmCardPayment(clientSecret, {
        payment_method: { card: { token: 'tok_visa' } }
      });
      if (result.error) console.error(result.error.message);
      else alert('Payment Successful!');
    })();
  }, [clientSecret]);

  return <div className="p-8">Processing Payment...</div>;
}
